# Copyright: Ankitects Pty Ltd and contributors
# License: GNU AGPL, version 3 or later; http://www.gnu.org/licenses/agpl.html

"""Tests for mediasrv security utilities."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path
from unittest import mock

import pytest

from aqt.mediasrv import (
    TRUSTED_PAGE_CSP,
    UNTRUSTED_MEDIA_CSP,
    BundledFileRequest,
    LegacyPage,
    LocalFileRequest,
    PageContext,
    UnsafePathException,
    _handle_builtin_file_request,
    _handle_local_file_request,
    _legacy_editor_content_security_policy,
    _untrusted_sveltekit_content_security_policy,
    ensure_safe_path,
    is_localhost_origin,
    legacy_page_data,
)


class TestEnsureSafePath:
    def setup_method(self) -> None:
        self.tmpdir = tempfile.mkdtemp()
        subdir = Path(self.tmpdir) / "sub"
        subdir.mkdir()
        (subdir / "file.txt").write_text("ok")

    def test_valid_subpath(self) -> None:
        result = ensure_safe_path(self.tmpdir, "sub/file.txt")
        assert result == os.path.join(os.path.realpath(self.tmpdir), "sub", "file.txt")

    def test_rejects_parent_traversal(self) -> None:
        with pytest.raises(UnsafePathException):
            ensure_safe_path(self.tmpdir, "../etc/passwd")

    def test_rejects_double_traversal(self) -> None:
        with pytest.raises(UnsafePathException):
            ensure_safe_path(self.tmpdir, "sub/../../etc/passwd")

    def test_rejects_absolute_path_escape(self) -> None:
        with pytest.raises(UnsafePathException):
            ensure_safe_path(self.tmpdir, "/etc/passwd")

    def test_rejects_base_dir_itself(self) -> None:
        with pytest.raises(UnsafePathException):
            ensure_safe_path(self.tmpdir, ".")

    def test_rejects_empty_path(self) -> None:
        with pytest.raises(UnsafePathException):
            ensure_safe_path(self.tmpdir, "")

    def test_accepts_pathlib_args(self) -> None:
        result = ensure_safe_path(Path(self.tmpdir), Path("sub/file.txt"))
        assert result.endswith(os.path.join("sub", "file.txt"))

    def test_normalizes_redundant_separators(self) -> None:
        result = ensure_safe_path(self.tmpdir, "sub///file.txt")
        assert result == os.path.join(os.path.realpath(self.tmpdir), "sub", "file.txt")

    def test_rejects_traversal_after_normalization(self) -> None:
        with pytest.raises(UnsafePathException):
            ensure_safe_path(self.tmpdir, "sub/../../../etc/passwd")


class TestIsLocalhostOrigin:
    @pytest.mark.parametrize(
        "origin",
        [
            "http://127.0.0.1:40000",
            "http://localhost:40000",
            "http://[::1]:40000",
            "https://127.0.0.1:40000",
            "https://localhost:40000",
            "https://[::1]:40000",
            "http://127.0.0.1",
            "http://localhost",
            "http://[::1]",
            "http://127.0.0.1/",
            "http://localhost/path",
        ],
    )
    def test_allowed_origins(self, origin: str) -> None:
        assert is_localhost_origin(origin) is True

    @pytest.mark.parametrize(
        "origin",
        [
            "http://evil.com",
            "http://127.0.0.1.evil.com",
            "http://localhost.evil.com",
            "http://evil.com:127.0.0.1",
            "http://notlocalhost:40000",
            "https://evil.com",
            "",
        ],
    )
    def test_rejected_origins(self, origin: str) -> None:
        assert is_localhost_origin(origin) is False


def _make_media_file(tmpdir: str, filename: str, content: bytes = b"test") -> str:
    path = os.path.join(tmpdir, filename)
    with open(path, "wb") as f:
        f.write(content)
    return filename


def _get_csp(response) -> str | None:
    return response.headers.get("Content-Security-Policy")


def _csp_directives(csp: str) -> dict[str, str]:
    directives = {}
    for part in csp.split(";"):
        name, _, value = part.strip().partition(" ")
        directives[name] = value
    return directives


class TestMediaFileCSP:
    """CSP headers on media file responses should block script execution."""

    @pytest.mark.parametrize("doctype", ["html", "svg"])
    def test_doc_has_csp_header(self, doctype: str) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmpdir:
            fname = _make_media_file(
                tmpdir, f"test.{doctype}", f"<{doctype}></{doctype}>".encode()
            )
            req = LocalFileRequest(root=tmpdir, path=fname)
            from aqt.mediasrv import app

            with app.test_request_context():
                resp = _handle_local_file_request(req)
            csp = _get_csp(resp)
            assert csp is not None, f"{doctype} response must have CSP header"

    def test_csp_blocks_connect_to_local_api(self) -> None:
        """Scripts must not be able to fetch() the local /_anki/ API.

        Even if script-src somehow gets relaxed in the future, connect-src
        should not allow http: (which includes http://127.0.0.1).
        """
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmpdir:
            fname = _make_media_file(tmpdir, "test.svg", b"<svg></svg>")
            req = LocalFileRequest(root=tmpdir, path=fname)
            from aqt.mediasrv import app

            with app.test_request_context():
                resp = _handle_local_file_request(req)
            csp = _get_csp(resp)
            assert csp is not None

            directives = _csp_directives(csp)
            connect_src = directives.get("connect-src", directives.get("default-src"))
            assert connect_src == "'none'", (
                f"CSP must not allow connections (enables local API access): {csp}"
            )

    def test_untrusted_media_is_sandboxed(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmpdir:
            fname = _make_media_file(tmpdir, "test.svg", b"<svg></svg>")
            req = LocalFileRequest(root=tmpdir, path=fname)
            from aqt.mediasrv import app

            with app.test_request_context():
                resp = _handle_local_file_request(req)
            csp = _get_csp(resp)
            assert csp == UNTRUSTED_MEDIA_CSP

            directives = _csp_directives(csp)
            assert directives["default-src"] == "'none'"
            assert directives["script-src"] == "'none'"
            assert directives["connect-src"] == "'none'"
            assert directives["object-src"] == "'none'"
            assert directives["frame-src"] == "'none'"
            assert directives["child-src"] == "'none'"
            assert directives["base-uri"] == "'none'"
            assert directives["form-action"] == "'none'"
            assert directives["sandbox"] == "allow-same-origin"
            assert "frame-ancestors" not in directives

    def test_untrusted_media_can_load_its_own_presentation(self) -> None:
        """Media embedded via <object>/<iframe> is a document of its own, and has to
        be able to load the stylesheets/images/fonts stored next to it."""
        directives = _csp_directives(UNTRUSTED_MEDIA_CSP)

        assert directives["style-src"] == "'self' 'unsafe-inline'"
        assert directives["img-src"] == "'self'"
        assert directives["font-src"] == "'self'"
        assert directives["media-src"] == "'self'"

        # ...but only passive resources, and only from our own server, so that
        # cards can neither execute code nor phone home
        for directive in ("script-src", "connect-src", "object-src", "frame-src"):
            assert directives[directive] == "'none'"
        for name, value in directives.items():
            assert not any(
                remote in value for remote in ("http:", "https:", "data:", "*")
            ), f"{name} must not allow remote sources: {value}"

    def test_trusted_local_file_does_not_get_untrusted_media_csp(self) -> None:
        """Add-on exports use LocalFileRequest too, but should not be sandboxed."""
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmpdir:
            fname = _make_media_file(tmpdir, "addon.html", b"<html></html>")
            req = LocalFileRequest(root=tmpdir, path=fname, untrusted=False)
            from aqt.mediasrv import app

            with app.test_request_context():
                resp = _handle_local_file_request(req)
            assert _get_csp(resp) is None


class TestCheckDynamicRequestPermissions:
    """A missing Content-type header must abort(403), not raise KeyError."""

    def test_missing_content_type_header_aborts_403(self, monkeypatch) -> None:
        from unittest import mock

        from werkzeug.exceptions import Forbidden

        import aqt
        from aqt.mediasrv import _check_dynamic_request_permissions, app

        monkeypatch.setattr(aqt, "mw", mock.Mock(), raising=False)

        with app.test_request_context(method="POST"):
            with pytest.raises(Forbidden):
                _check_dynamic_request_permissions()


class TestEditorPageCSP:
    def test_editor_csp_does_not_block_user_embeds(self) -> None:
        csp = _legacy_editor_content_security_policy(port=12345)
        directives = _csp_directives(csp)

        assert directives["script-src"] == (
            "http://127.0.0.1:12345/_anki/ http://127.0.0.1:12345/_addons/"
        )
        assert "object-src" not in directives
        assert "frame-src" not in directives
        assert "child-src" not in directives
        assert "img-src" not in directives

    @pytest.mark.parametrize(
        "csp",
        [
            _legacy_editor_content_security_policy(port=12345),
            _untrusted_sveltekit_content_security_policy(12345, "'sha256-abc='"),
        ],
    )
    def test_editor_csp_blocks_navigation_and_framing(self, csp: str) -> None:
        """Field content must not navigate the editor webview via a form, and
        the editor itself must not be framed by other pages."""
        directives = _csp_directives(csp)
        assert directives["form-action"] == "'none'"
        assert directives["frame-ancestors"] == "'none'"

    def test_sveltekit_editor_csp_allows_render_script_hash(self) -> None:
        csp = _untrusted_sveltekit_content_security_policy(12345, "'sha256-abc='")
        directives = _csp_directives(csp)
        assert directives["script-src"].split() == [
            "http://127.0.0.1:12345/_anki/",
            "http://127.0.0.1:12345/_app/",
            "http://127.0.0.1:12345/_addons/",
            "'sha256-abc='",
        ]


class TestTrustedPageCSP:
    """Internal pages are only shown top-level. Refusing frame ancestors keeps
    note HTML in the editor from embedding them in the API-access profile
    (GHSA-jw6j-j4mf-8jgm)."""

    SVELTEKIT_INDEX = (
        b'<html><head><meta http-equiv="content-security-policy" '
        b"content=\"script-src 'self' 'sha256-abc='\"></head></html>"
    )

    def _mock_mw(self, monkeypatch) -> mock.Mock:
        import aqt

        mw = mock.Mock()
        mw.mediaServer.getPort.return_value = 12345
        monkeypatch.setattr(aqt, "mw", mw, raising=False)
        return mw

    def _serve_builtin(self, monkeypatch, request: BundledFileRequest, data: bytes):
        from aqt import mediasrv

        self._mock_mw(monkeypatch)
        monkeypatch.setattr(mediasrv, "_builtin_data", lambda path: data)
        with mediasrv.app.test_request_context():
            return _handle_builtin_file_request(request)

    def test_trusted_sveltekit_page_refuses_framing(self, monkeypatch) -> None:
        request = BundledFileRequest(
            "sveltekit/index.html", sveltekit_route="deck-options"
        )
        resp = self._serve_builtin(monkeypatch, request, self.SVELTEKIT_INDEX)
        assert _get_csp(resp) == TRUSTED_PAGE_CSP
        assert b"content-security-policy" not in resp.get_data()

    @pytest.mark.parametrize("route", ["editor", "image-occlusion"])
    def test_untrusted_sveltekit_page_refuses_framing(
        self, monkeypatch, route: str
    ) -> None:
        request = BundledFileRequest("sveltekit/index.html", sveltekit_route=route)
        resp = self._serve_builtin(monkeypatch, request, self.SVELTEKIT_INDEX)
        csp = _get_csp(resp)
        assert csp is not None
        directives = _csp_directives(csp)
        assert directives["form-action"] == "'none'"
        assert directives["frame-ancestors"] == "'none'"
        assert "'sha256-abc='" in directives["script-src"]

    def test_bundled_html_page_refuses_framing(self, monkeypatch) -> None:
        request = BundledFileRequest("pages/deckconfig.html")
        resp = self._serve_builtin(monkeypatch, request, b"<html></html>")
        assert _get_csp(resp) == TRUSTED_PAGE_CSP

    def test_bundled_asset_has_no_csp(self, monkeypatch) -> None:
        request = BundledFileRequest("js/foo.js")
        resp = self._serve_builtin(monkeypatch, request, b"console.log(1)")
        assert _get_csp(resp) is None

    @pytest.mark.parametrize(
        "context", [PageContext.REVIEWER, PageContext.PREVIEWER, PageContext.UNKNOWN]
    )
    def test_legacy_page_refuses_framing(self, monkeypatch, context) -> None:
        from aqt.mediasrv import app

        mw = self._mock_mw(monkeypatch)
        mw.mediaServer.get_page.return_value = LegacyPage("<html></html>", context)
        with app.test_request_context("/_anki/legacyPageData?id=1"):
            resp = legacy_page_data()
        assert _get_csp(resp) == TRUSTED_PAGE_CSP

    def test_legacy_editor_page_gets_editor_csp(self, monkeypatch) -> None:
        from aqt.mediasrv import app

        mw = self._mock_mw(monkeypatch)
        mw.mediaServer.get_page.return_value = LegacyPage(
            "<html></html>", PageContext.EDITOR
        )
        with app.test_request_context("/_anki/legacyPageData?id=1"):
            resp = legacy_page_data()
        assert _get_csp(resp) == _legacy_editor_content_security_policy(12345)
