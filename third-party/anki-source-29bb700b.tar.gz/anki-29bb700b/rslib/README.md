Anki's Rust code.
